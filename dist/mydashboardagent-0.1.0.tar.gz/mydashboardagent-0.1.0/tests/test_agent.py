# tests/test_agent.py
import pytest
from mydashboardagent import DashboardAgent

def test_collect_system_stats():
    agent = DashboardAgent()
    stats = agent.collect_system_stats()
    assert "cpu_percent" in stats
    assert "memory" in stats
    assert "disk" in stats
    assert "net" in stats

def test_file_listing(tmp_path):
    # Setup temp dir
    test_file = tmp_path / "example.txt"
    test_file.write_text("Hello world!")

    agent = DashboardAgent()
    contents = agent.list_files(tmp_path)
    names = [entry["name"] for entry in contents]
    assert "example.txt" in names
