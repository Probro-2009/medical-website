# src/mydashboardagent/filesystem/explorer.py
import os
from pathlib import Path

def list_directory(path=".") -> list[dict]:
    """List contents of a directory."""
    path = Path(path)
    if not path.is_dir():
        raise NotADirectoryError(f"{path} is not a directory")

    return [{
        "name": f.name,
        "is_dir": f.is_dir(),
        "size": f.stat().st_size,
        "modified": f.stat().st_mtime
    } for f in path.iterdir()]

def read_file(file_path: str) -> str:
    return Path(file_path).read_text(encoding="utf-8")

def write_file(file_path: str, content: str) -> None:
    Path(file_path).write_text(content, encoding="utf-8")

def delete_path(target_path: str) -> None:
    path = Path(target_path)
    if path.is_dir():
        os.rmdir(path)
    else:
        path.unlink()

def create_file(file_path: str) -> None:
    Path(file_path).touch()

def create_directory(dir_path: str) -> None:
    Path(dir_path).mkdir(parents=True, exist_ok=True)
