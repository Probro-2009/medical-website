# src/mydashboardagent/telemetry/system.py
import psutil

def get_stats():
    return {
        "cpu_percent": psutil.cpu_percent(interval=3),
        "memory": dict(psutil.virtual_memory()._asdict()),
        "disk": dict(psutil.disk_usage("/")._asdict()),
        "net": dict(psutil.net_io_counters()._asdict()),
    }
