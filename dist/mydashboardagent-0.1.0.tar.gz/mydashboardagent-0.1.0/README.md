# MyDashboardAgent

📡 A lightweight Python agent for your SaaS Developer Dashboard.

It collects:
- ✅ CPU, RAM, Disk, Network metrics (via `psutil`)
- ✅ API endpoint health checks
- ✅ Filesystem access (list, edit, delete, create)
- ✅ Media uploads
- ✅ Audit/log tailing
- ✅ DB snapshot export (read-only)
- ✅ Chatbot transcript archiving (.txt)
- ✅ On-demand security scans (Bandit)

## Install

```bash
pip install mydashboardagent
