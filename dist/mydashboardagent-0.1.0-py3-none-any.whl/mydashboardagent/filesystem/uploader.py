# src/mydashboardagent/filesystem/uploader.py
from pathlib import Path
import shutil

def save_file(source_path: str, target_dir: str) -> str:
    """Copy a media file to a directory."""
    src = Path(source_path)
    tgt_dir = Path(target_dir)
    if not src.exists() or not tgt_dir.exists():
        raise FileNotFoundError("Source or target directory not found")

    tgt_path = tgt_dir / src.name
    shutil.copy2(src, tgt_path)
    return str(tgt_path)
