# src/mydashboardagent/chatbot/archiver.py
from pathlib import Path
import datetime

def save_chats(chat_messages: list[str], output_path: str = None) -> str:
    """
    Saves a list of chat messages to a timestamped .txt file.
    Returns the path to the saved file.
    """
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"chatlog_{timestamp}.txt"
    
    if output_path:
        out_file = Path(output_path) / filename
    else:
        out_file = Path.cwd() / filename

    out_file.write_text("\n".join(chat_messages), encoding="utf-8")
    return str(out_file)
