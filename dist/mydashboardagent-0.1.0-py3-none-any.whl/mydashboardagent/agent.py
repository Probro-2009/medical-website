# src/mydashboardagent/agent.py
from .telemetry import system
from .filesystem import explorer
from .logs import collector
from .chatbot import archiver
from .database import exporter

class DashboardAgent:
    def collect_system_stats(self):
        return system.get_stats()

    def list_files(self, base_path="."):
        return explorer.list_directory(base_path)

    def get_logs(self, log_paths): 
      from .logs import collector
      return collector.collect_logs(log_paths)


    def export_database(self, db_path):
        return exporter.dump_file(db_path)

    def archive_chat_logs(self, chat_data: list[str], out_path: str):
        return archiver.save_chats(chat_data, out_path)

    def scan_security(self):
        from .telemetry import security
        return security.run_scan()
