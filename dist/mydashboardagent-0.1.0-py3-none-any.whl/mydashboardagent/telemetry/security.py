# src/mydashboardagent/telemetry/security.py
import subprocess
import tempfile
import os

def run_scan(scan_path=".") -> dict:
    """
    Run a security scan using Bandit on Python files.
    Returns scan report even if vulnerabilities are found.
    """
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as tmpfile:
            report_path = tmpfile.name

        cmd = [
            "bandit", "-r", scan_path,
            "-f", "json", "-o", report_path
        ]
        # don't fail if exit code is 1 (vulnerabilities found)
        subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        with open(report_path, "r") as f:
            report = f.read()
        os.unlink(report_path)
        return {
            "tool": "bandit",
            "path": scan_path,
            "report": report
        }

    except Exception as e:
        return {
            "tool": "bandit",
            "path": scan_path,
            "error": str(e)
        }
