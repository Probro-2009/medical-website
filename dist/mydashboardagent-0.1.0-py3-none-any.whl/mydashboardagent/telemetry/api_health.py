# src/mydashboardagent/telemetry/api_health.py
import requests
import time

def check_endpoints(endpoints: list[str], timeout: int = 5) -> list[dict]:
    """Check the health of given API endpoints."""
    results = []
    for url in endpoints:
        start = time.time()
        try:
            resp = requests.get(url, timeout=timeout)
            duration = time.time() - start
            results.append({
                "url": url,
                "status_code": resp.status_code,
                "response_time_sec": round(duration, 3),
                "ok": resp.ok
            })
        except Exception as e:
            results.append({
                "url": url,
                "error": str(e),
                "ok": False
            })
    return results
