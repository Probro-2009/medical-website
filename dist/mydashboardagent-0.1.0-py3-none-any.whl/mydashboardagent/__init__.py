# src/mydashboardagent/__init__.py
from .agent import DashboardAgent
__all__ = ["DashboardAgent"]
__version__ = "0.1.0"
