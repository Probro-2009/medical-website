# src/mydashboardagent/logs/collector.py
from pathlib import Path

def collect_logs(log_paths: list[str]) -> dict:
    """
    Reads the last 100 lines from each specified log or audit file.
    Returns a dictionary: {filename: [lines]}.
    """
    logs = {}
    for path_str in log_paths:
        path = Path(path_str)
        if path.exists() and path.is_file():
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()[-100:]
            logs[path.name] = lines
        else:
            logs[path.name] = [f"File not found: {path_str}"]
    return logs
