from .collector import collect_logs
__all__ = ["collect_logs"]
