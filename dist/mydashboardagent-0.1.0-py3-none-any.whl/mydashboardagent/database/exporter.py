# src/mydashboardagent/database/exporter.py
from pathlib import Path
import shutil
import tempfile

def dump_file(db_path: str) -> str:
    """Copy a database file to a temporary read-only location."""
    path = Path(db_path)
    if not path.exists():
        raise FileNotFoundError(f"Database file not found: {db_path}")

    tmp_dir = tempfile.gettempdir()
    dump_path = Path(tmp_dir) / f"{path.stem}_dump{path.suffix}"
    shutil.copy2(path, dump_path)
    dump_path.chmod(0o444)  # Read-only
    return str(dump_path)
